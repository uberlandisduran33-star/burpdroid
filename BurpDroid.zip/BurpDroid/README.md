# BurpDroid

Proxy MITM local para Android 14, hecho en Kotlin. Núcleo funcional de Burp Suite:
captura de tráfico HTTP/HTTPS, Intercept (editar antes de reenviar), Repeater e
Intruder básico (sustitución de payloads).

## Cómo compilarlo

1. Abre la carpeta `BurpDroid/` con **Android Studio** (Koala o más reciente).
2. Deja que Gradle sincronice — descargará BouncyCastle y el resto de dependencias
   automáticamente (necesitas conexión a internet solo para esta sincronización).
3. Conecta tu teléfono (Android 14, depuración USB activada) o usa un emulador,
   y pulsa Run.

No pude compilarlo ni probarlo yo mismo: este entorno no tiene el SDK de Android
ni acceso a red para descargar Gradle/dependencias. El código está escrito con
cuidado y usa APIs estándar, pero es normal que al compilar aparezcan uno o dos
ajustes menores que resolver en Android Studio.

## Cómo usarlo en tu teléfono

1. Abre la app y pulsa **"Iniciar proxy"** (arranca un servicio en primer plano
   escuchando en `127.0.0.1:8888`).
2. Pulsa **"Exportar CA"** para compartir/guardar el certificado raíz generado
   en el propio dispositivo.
3. Instálalo: Ajustes → Seguridad → Cifrado y credenciales → Instalar un
   certificado → CA de la CA. En Android 14 puede pedirte fijar una pantalla de
   bloqueo (PIN/patrón) para poder instalar certificados de usuario.
4. Ve a Ajustes Wi-Fi → mantén pulsada tu red → Modificar red → Opciones
   avanzadas → Proxy: **Manual** → Host `127.0.0.1`, Puerto `8888`.
5. Navega o usa apps normalmente: las peticiones que pasen por ese proxy
   aparecerán en la lista principal.
6. **Intercept: ON** detiene cada petición antes de enviarla y abre una pantalla
   para editarla (o descartarla) antes de reenviar.
7. Toca cualquier transacción capturada para ver request/response en crudo, y
   desde ahí mándala a **Repeater** para reenviarla modificada cuantas veces
   quieras.
8. **Intruder** te deja pegar una plantilla de petición con un marcador
   `§payload§` y una lista de payloads (uno por línea); las envía todas en
   serie y muestra status/tamaño/tiempo de cada una.

## Limitaciones importantes (léelas antes de asumir que "no funciona")

- **Solo captura tráfico que respete el proxy del sistema.** Muchas apps
  modernas (bancos, WhatsApp, Instagram, Chrome con ciertas configuraciones)
  usan *certificate pinning* o ignoran el proxy del sistema, así que no vas a
  ver ni poder interceptar su tráfico aunque la CA esté instalada. Esto es una
  limitación de la plataforma, no un bug: es exactamente lo mismo que le pasa
  a Burp Suite, Charles Proxy o mitmproxy con esas mismas apps.
- Funciona muy bien para: WebView de tus propias apps en desarrollo, la
  mayoría del tráfico del navegador del sistema, y cualquier app tuya que no
  implemente pinning.
- No implementa un stack de VPN/TUN a nivel de paquete IP (eso exigiría
  reimplementar TCP/IP en espacio de usuario). El enfoque aquí es proxy manual
  de sistema, que es más simple, más estable, y cubre el caso de uso real de
  "interceptar y modificar tráfico HTTP para pruebas" sin la complejidad de un
  proxy transparente.
- Es software de un solo archivo de proceso (todo en memoria); si cierras la
  app pierdes el historial de transacciones. Si lo necesitas, la capa lógica
  para persistir en Room/SQLite es un añadido sencillo sobre
  `TransactionRepository`.
- Solo confirma en la práctica que compila y funciona probándolo tú en Android
  Studio — yo no pude verificarlo en este entorno.

## Estructura del proyecto

```
app/src/main/java/com/uberlandis/burpdroid/
  mitm/        -> CertificateAuthority, MitmProxyServer, HttpParser, InterceptResolver
  model/       -> HttpTransaction
  data/        -> TransactionRepository (estado en memoria + LiveData)
  service/     -> ProxyService (foreground service)
  ui/          -> MainActivity, TransactionDetailActivity, RepeaterActivity,
                  IntruderActivity, InterceptActivity, TransactionAdapter
```

## Uso responsable

Esta herramienta está pensada para inspeccionar y depurar **tu propio**
tráfico de red (tus apps en desarrollo, tu propio teléfono, tus propias
pruebas de seguridad). Interceptar tráfico de terceros sin autorización es
ilegal en la mayoría de jurisdicciones.
