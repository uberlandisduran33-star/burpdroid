package com.uberlandis.burpdroid.mitm

import android.content.Context
import android.util.Log
import com.uberlandis.burpdroid.data.TransactionRepository
import com.uberlandis.burpdroid.model.HttpTransaction
import com.uberlandis.burpdroid.model.TxState
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket

/**
 * Proxy HTTP/HTTPS local. Configura este proxy manualmente en Ajustes Wi-Fi del
 * teléfono (avanzado > proxy manual > host 127.0.0.1, puerto el que elijas aquí),
 * o desde otro dispositivo en la misma red apuntando a la IP de este teléfono.
 *
 * Para HTTPS: recibe el CONNECT, y en vez de solo hacer túnel ciego, genera un
 * certificado hoja para ese host (firmado por nuestra CA local) y termina TLS
 * aquí mismo, para poder leer y modificar el tráfico antes de reenviarlo al
 * servidor real por una segunda conexión TLS saliente.
 */
class MitmProxyServer(
    private val context: Context,
    private val port: Int,
    private val ca: CertificateAuthority
) {
    private val TAG = "MitmProxyServer"
    private var serverSocket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var running = false

    fun start() {
        running = true
        serverSocket = ServerSocket(port)
        pool.execute {
            while (running) {
                try {
                    val client = serverSocket?.accept() ?: break
                    pool.execute { handleClient(client) }
                } catch (e: Exception) {
                    if (running) Log.e(TAG, "accept() falló", e)
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        pool.shutdownNow()
    }

    private fun handleClient(client: Socket) {
        try {
            val input = client.getInputStream()
            val firstLine = HttpParser.readLine(input) ?: return
            val reqLine = HttpParser.parseRequestLine(firstLine)

            if (reqLine.method.equals("CONNECT", ignoreCase = true)) {
                handleConnect(client, input, reqLine.target)
            } else {
                handlePlainHttp(client, input, reqLine, firstLine)
            }
        } catch (e: Exception) {
            Log.w(TAG, "handleClient error: ${e.message}")
        } finally {
            runCatching { client.close() }
        }
    }

    // ---------- HTTP plano (host:80) ----------

    private fun handlePlainHttp(client: Socket, input: InputStream, reqLine: RequestLine, firstLine: String) {
        val headers = HttpParser.readHeaders(input)
        val body = HttpParser.readBody(input, headers)
        val host = HttpParser.headerValue(headers, "Host") ?: reqLine.target

        val tx = HttpTransaction(
            method = reqLine.method, scheme = "http", host = host, path = reqLine.target,
            requestHeaders = headers, requestBody = body
        )

        val approved = InterceptGate.gate(tx) ?: return // droppeada por el usuario
        relayPlain(client, approved, host)
    }

    private fun relayPlain(client: Socket, tx: HttpTransaction, host: String) {
        val hostOnly = host.substringBefore(':')
        val port = host.substringAfter(':', "80").toIntOrNull() ?: 80
        val start = System.currentTimeMillis()

        Socket(hostOnly, port).use { upstream ->
            HttpParser.writeRaw(upstream.getOutputStream(), "${tx.method} ${tx.path} HTTP/1.1", tx.requestHeaders, tx.requestBody)
            val upIn = upstream.getInputStream()
            val statusLine = HttpParser.readLine(upIn) ?: "HTTP/1.1 502 Bad Gateway"
            val status = HttpParser.parseStatusLine(statusLine)
            val respHeaders = HttpParser.readHeaders(upIn)
            val respBody = HttpParser.readBody(upIn, respHeaders)

            tx.responseStatus = status.status
            tx.responseHeaders = respHeaders
            tx.responseBody = respBody
            tx.durationMs = System.currentTimeMillis() - start
            tx.state = TxState.FORWARDED
            TransactionRepository.add(tx)

            HttpParser.writeRaw(client.getOutputStream(), statusLine, respHeaders, respBody)
        }
    }

    // ---------- HTTPS (CONNECT + terminación TLS local) ----------

    private fun handleConnect(client: Socket, input: InputStream, target: String) {
        // Consumir el resto de cabeceras del CONNECT
        HttpParser.readHeaders(input)
        client.getOutputStream().write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
        client.getOutputStream().flush()

        val host = target.substringBefore(':')
        val remotePort = target.substringAfter(':', "443").toIntOrNull() ?: 443

        val sslContext = buildServerSslContext(host)
        val sslSocket = sslContext.socketFactory.createSocket(client, client.inetAddress.hostAddress, client.port, false) as SSLSocket
        sslSocket.useClientMode = false
        sslSocket.startHandshake()

        val tlsIn = sslSocket.inputStream
        val firstLine = HttpParser.readLine(tlsIn) ?: return
        val reqLine = HttpParser.parseRequestLine(firstLine)
        val headers = HttpParser.readHeaders(tlsIn)
        val body = HttpParser.readBody(tlsIn, headers)

        val tx = HttpTransaction(
            method = reqLine.method, scheme = "https", host = host, path = reqLine.target,
            requestHeaders = headers, requestBody = body
        )

        val approved = InterceptGate.gate(tx) ?: return
        relayTls(sslSocket, approved, host, remotePort)
    }

    private fun relayTls(clientTls: SSLSocket, tx: HttpTransaction, host: String, remotePort: Int) {
        val start = System.currentTimeMillis()
        val upstreamContext = SSLContext.getInstance("TLS").apply { init(null, null, null) }
        val upstream = upstreamContext.socketFactory.createSocket(host, remotePort) as SSLSocket

        upstream.use {
            HttpParser.writeRaw(upstream.outputStream, "${tx.method} ${tx.path} HTTP/1.1", tx.requestHeaders, tx.requestBody)
            val upIn = upstream.inputStream
            val statusLine = HttpParser.readLine(upIn) ?: "HTTP/1.1 502 Bad Gateway"
            val status = HttpParser.parseStatusLine(statusLine)
            val respHeaders = HttpParser.readHeaders(upIn)
            val respBody = HttpParser.readBody(upIn, respHeaders)

            tx.responseStatus = status.status
            tx.responseHeaders = respHeaders
            tx.responseBody = respBody
            tx.durationMs = System.currentTimeMillis() - start
            tx.state = TxState.FORWARDED
            TransactionRepository.add(tx)

            HttpParser.writeRaw(clientTls.outputStream, statusLine, respHeaders, respBody)
        }
    }

    private fun buildServerSslContext(host: String): SSLContext {
        val ks: KeyStore = ca.keyStoreFor(host)
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, ca.keyStorePassword())
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, null, null)
        return ctx
    }
}

/** Punto único donde toda petición pasa por la cola de intercepción si está activa. */
object InterceptGate {
    /** Devuelve la transacción (posiblemente editada) a reenviar, o null si el usuario la descartó. */
    fun gate(tx: HttpTransaction): HttpTransaction? {
        if (!TransactionRepository.interceptEnabled) return tx
        tx.state = TxState.INTERCEPTED
        TransactionRepository.add(tx)
        TransactionRepository.interceptQueue.put(tx)
        // Bloquea este hilo de conexión hasta que la UI resuelva la transacción
        // (forward / edit+forward / drop), vía InterceptResolver.
        return InterceptResolver.awaitResolution(tx.id)
    }
}
