package com.uberlandis.burpdroid.mitm

import java.io.ByteArrayOutputStream
import java.io.InputStream

data class RequestLine(val method: String, val target: String, val version: String)
data class StatusLine(val version: String, val status: Int, val reason: String)

object HttpParser {

    /** Lee una línea terminada en \r\n de un InputStream, sin buffering (para poder
     *  luego leer el cuerpo binario del mismo stream sin perder bytes). */
    fun readLine(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        var prev = -1
        while (true) {
            val b = input.read()
            if (b == -1) return if (buf.size() == 0) null else buf.toString("ISO-8859-1")
            if (prev == '\r'.code && b == '\n'.code) {
                val bytes = buf.toByteArray()
                return String(bytes, 0, bytes.size - 1, Charsets.ISO_8859_1)
            }
            buf.write(b)
            prev = b
        }
    }

    fun parseRequestLine(line: String): RequestLine {
        val parts = line.trim().split(" ")
        return RequestLine(parts.getOrElse(0) { "GET" }, parts.getOrElse(1) { "/" }, parts.getOrElse(2) { "HTTP/1.1" })
    }

    fun parseStatusLine(line: String): StatusLine {
        val parts = line.trim().split(" ", limit = 3)
        return StatusLine(parts.getOrElse(0) { "HTTP/1.1" }, parts.getOrElse(1) { "0" }.toIntOrNull() ?: 0, parts.getOrElse(2) { "" })
    }

    fun readHeaders(input: InputStream): MutableList<Pair<String, String>> {
        val headers = mutableListOf<Pair<String, String>>()
        while (true) {
            val line = readLine(input) ?: break
            if (line.isEmpty()) break
            val idx = line.indexOf(':')
            if (idx > 0) {
                headers.add(line.substring(0, idx).trim() to line.substring(idx + 1).trim())
            }
        }
        return headers
    }

    fun headerValue(headers: List<Pair<String, String>>, name: String): String? =
        headers.firstOrNull { it.first.equals(name, ignoreCase = true) }?.second

    /** Lee el cuerpo según Content-Length o Transfer-Encoding: chunked. Si no hay
     *  ninguno, devuelve vacío (típico en GET). */
    fun readBody(input: InputStream, headers: List<Pair<String, String>>): ByteArray {
        val contentLength = headerValue(headers, "Content-Length")?.toIntOrNull()
        val transferEncoding = headerValue(headers, "Transfer-Encoding")

        if (transferEncoding?.contains("chunked", ignoreCase = true) == true) {
            return readChunked(input)
        }
        if (contentLength != null && contentLength > 0) {
            val out = ByteArray(contentLength)
            var read = 0
            while (read < contentLength) {
                val n = input.read(out, read, contentLength - read)
                if (n == -1) break
                read += n
            }
            return out
        }
        return ByteArray(0)
    }

    private fun readChunked(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        while (true) {
            val sizeLine = readLine(input) ?: break
            val size = sizeLine.trim().substringBefore(';').toIntOrNull(16) ?: break
            if (size == 0) {
                // consumir trailer + línea en blanco final
                while (true) {
                    val trailer = readLine(input) ?: break
                    if (trailer.isEmpty()) break
                }
                break
            }
            val chunk = ByteArray(size)
            var read = 0
            while (read < size) {
                val n = input.read(chunk, read, size - read)
                if (n == -1) break
                read += n
            }
            out.write(chunk)
            readLine(input) // CRLF final del chunk
        }
        return out.toByteArray()
    }

    fun writeRaw(out: java.io.OutputStream, requestLine: String, headers: List<Pair<String, String>>, body: ByteArray) {
        val sb = StringBuilder()
        sb.append(requestLine).append("\r\n")
        headers.forEach { (k, v) -> sb.append(k).append(": ").append(v).append("\r\n") }
        sb.append("\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        if (body.isNotEmpty()) out.write(body)
        out.flush()
    }
}
