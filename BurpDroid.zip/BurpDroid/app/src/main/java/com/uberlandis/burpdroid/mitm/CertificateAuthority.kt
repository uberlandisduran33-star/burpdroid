package com.uberlandis.burpdroid.mitm

import android.content.Context
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.BasicConstraints
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.GeneralName
import org.bouncycastle.asn1.x509.GeneralNames
import org.bouncycastle.asn1.x509.KeyUsage
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Security
import java.security.cert.X509Certificate
import java.util.Date
import java.util.concurrent.ConcurrentHashMap

/**
 * Genera y guarda una CA raíz propia del dispositivo (una sola vez), y firma
 * certificados hoja por dominio bajo demanda para poder terminar TLS localmente
 * e inspeccionar el tráfico. El usuario debe instalar y confiar manualmente en
 * la CA raíz (Ajustes > Seguridad > Cifrado y credenciales > Instalar certificado)
 * para que las apps que respeten el almacén de "user" confíen en las conexiones.
 */
class CertificateAuthority(context: Context) {

    private val caDir = File(context.filesDir, "ca").apply { mkdirs() }
    private val caCertFile = File(caDir, "burpdroid_ca.crt")
    private val caKeystoreFile = File(caDir, "burpdroid_ca.p12")
    private val keystorePassword = "burpdroid".toCharArray()

    lateinit var caCert: X509Certificate
        private set
    private lateinit var caKey: PrivateKey

    private val leafCache = ConcurrentHashMap<String, Pair<X509Certificate, PrivateKey>>()

    init {
        Security.addProvider(BouncyCastleProvider())
        if (caKeystoreFile.exists()) {
            load()
        } else {
            generateRootCa()
            save()
        }
    }

    val certFileForExport: File get() = caCertFile

    private fun generateRootCa() {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp: KeyPair = kpg.generateKeyPair()

        val subject = X500Name("CN=BurpDroid Local CA, O=BurpDroid, OU=Generated on-device")
        val serial = BigInteger.valueOf(System.currentTimeMillis())
        val notBefore = Date(System.currentTimeMillis() - 86_400_000L)
        val notAfter = Date(System.currentTimeMillis() + 10L * 365 * 86_400_000L)

        val builder = JcaX509v3CertificateBuilder(subject, serial, notBefore, notAfter, subject, kp.public)
        builder.addExtension(Extension.basicConstraints, true, BasicConstraints(true))
        builder.addExtension(Extension.keyUsage, true, KeyUsage(KeyUsage.keyCertSign or KeyUsage.cRLSign))

        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val holder = builder.build(signer)
        val cert = JcaX509CertificateConverter().getCertificate(holder)

        caCert = cert
        caKey = kp.private

        caCertFile.writeBytes(cert.encoded)
    }

    private fun save() {
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry("ca", caKey, keystorePassword, arrayOf(caCert))
        FileOutputStream(caKeystoreFile).use { ks.store(it, keystorePassword) }
    }

    private fun load() {
        val ks = KeyStore.getInstance("PKCS12")
        FileInputStream(caKeystoreFile).use { ks.load(it, keystorePassword) }
        caKey = ks.getKey("ca", keystorePassword) as PrivateKey
        caCert = ks.getCertificate("ca") as X509Certificate
        if (!caCertFile.exists()) caCertFile.writeBytes(caCert.encoded)
    }

    /** Devuelve (y cachea) un par cert+clave hoja válido para [host], firmado por nuestra CA. */
    fun leafFor(host: String): Pair<X509Certificate, PrivateKey> {
        leafCache[host]?.let { return it }
        synchronized(this) {
            leafCache[host]?.let { return it }
            val pair = signLeaf(host)
            leafCache[host] = pair
            return pair
        }
    }

    private fun signLeaf(host: String): Pair<X509Certificate, PrivateKey> {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp = kpg.generateKeyPair()

        val subject = X500Name("CN=$host, O=BurpDroid")
        val serial = BigInteger.valueOf(System.currentTimeMillis() + host.hashCode())
        val notBefore = Date(System.currentTimeMillis() - 86_400_000L)
        val notAfter = Date(System.currentTimeMillis() + 825L * 86_400_000L)

        val builder = JcaX509v3CertificateBuilder(
            X500Name(caCert.subjectX500Principal.name),
            serial, notBefore, notAfter, subject, kp.public
        )
        builder.addExtension(Extension.basicConstraints, false, BasicConstraints(false))
        builder.addExtension(
            Extension.subjectAlternativeName, false,
            GeneralNames(GeneralName(GeneralName.dNSName, host))
        )
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(caKey)
        val holder = builder.build(signer)
        val cert = JcaX509CertificateConverter().getCertificate(holder)
        return cert to kp.private
    }

    /** Construye un KeyStore en memoria (leaf + cadena CA) listo para un KeyManagerFactory. */
    fun keyStoreFor(host: String): KeyStore {
        val (leaf, leafKey) = leafFor(host)
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry("leaf", leafKey, keystorePassword, arrayOf(leaf, caCert))
        return ks
    }

    fun keyStorePassword() = keystorePassword
}
