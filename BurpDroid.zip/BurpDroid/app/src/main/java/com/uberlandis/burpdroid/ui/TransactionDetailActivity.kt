package com.uberlandis.burpdroid.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.uberlandis.burpdroid.data.TransactionRepository
import com.uberlandis.burpdroid.databinding.ActivityTransactionDetailBinding

class TransactionDetailActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_ID = "tx_id"
        fun intent(ctx: Context, txId: String) = Intent(ctx, TransactionDetailActivity::class.java)
            .putExtra(EXTRA_ID, txId)
    }

    private lateinit var binding: ActivityTransactionDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransactionDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getStringExtra(EXTRA_ID) ?: return finish()
        val tx = TransactionRepository.get(id) ?: return finish()

        binding.txtUrl.text = tx.url
        binding.txtRequest.text = tx.rawRequest()
        binding.txtResponse.text = tx.rawResponse()

        binding.btnSendToRepeater.setOnClickListener {
            startActivity(RepeaterActivity.intent(this, tx.id))
        }
    }
}
