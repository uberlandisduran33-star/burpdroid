package com.uberlandis.burpdroid.data

import androidx.lifecycle.MutableLiveData
import com.uberlandis.burpdroid.model.HttpTransaction
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue

/**
 * Singleton simple. En una app real esto sería inyectado, pero para un proyecto
 * de un solo usuario/proceso esto es suficiente y evita añadir DI.
 */
object TransactionRepository {

    private val list = CopyOnWriteArrayList<HttpTransaction>()
    val liveList = MutableLiveData<List<HttpTransaction>>(emptyList())

    // Cola de transacciones detenidas mientras "Intercept" está activo.
    val interceptQueue = LinkedBlockingQueue<HttpTransaction>()
    var interceptEnabled = false

    fun add(tx: HttpTransaction) {
        list.add(0, tx)
        publish()
    }

    fun update(tx: HttpTransaction) {
        val idx = list.indexOfFirst { it.id == tx.id }
        if (idx >= 0) list[idx] = tx
        publish()
    }

    fun clear() {
        list.clear()
        publish()
    }

    fun get(id: String): HttpTransaction? = list.firstOrNull { it.id == id }

    private fun publish() {
        liveList.postValue(list.toList())
    }
}
