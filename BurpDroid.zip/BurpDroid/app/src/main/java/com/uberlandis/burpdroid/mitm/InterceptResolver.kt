package com.uberlandis.burpdroid.mitm

import com.uberlandis.burpdroid.model.HttpTransaction
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.SynchronousQueue

/**
 * Puente entre el hilo de red (que espera) y la UI (que decide forward/edit/drop).
 * Cada transacción interceptada obtiene una cola de un solo elemento; la UI deposita
 * el resultado (tx editada, o null si se descarta) y el hilo de red lo recoge.
 */
object InterceptResolver {
    private val pending = ConcurrentHashMap<String, SynchronousQueue<HttpTransaction?>>()

    fun awaitResolution(txId: String): HttpTransaction? {
        val queue = SynchronousQueue<HttpTransaction?>()
        pending[txId] = queue
        return try {
            queue.take()
        } finally {
            pending.remove(txId)
        }
    }

    /** Llamado desde la UI: reenvía (con posibles ediciones) o descarta ([resolved] = null). */
    fun resolve(txId: String, resolved: HttpTransaction?) {
        pending[txId]?.put(resolved)
    }
}
