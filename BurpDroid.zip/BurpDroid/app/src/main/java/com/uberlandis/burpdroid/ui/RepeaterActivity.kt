package com.uberlandis.burpdroid.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.uberlandis.burpdroid.data.TransactionRepository
import com.uberlandis.burpdroid.databinding.ActivityRepeaterBinding
import com.uberlandis.burpdroid.mitm.HttpParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.net.Socket
import javax.net.ssl.SSLSocketFactory

class RepeaterActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_ID = "tx_id"
        fun intent(ctx: Context, txId: String) = Intent(ctx, RepeaterActivity::class.java).putExtra(EXTRA_ID, txId)
    }

    private lateinit var binding: ActivityRepeaterBinding
    private var scheme = "https"
    private var host = ""
    private var port = 443

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRepeaterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getStringExtra(EXTRA_ID)
        val tx = id?.let { TransactionRepository.get(it) }
        if (tx != null) {
            scheme = tx.scheme
            host = tx.host.substringBefore(':')
            port = tx.host.substringAfter(':', if (scheme == "https") "443" else "80").toIntOrNull()
                ?: if (scheme == "https") 443 else 80
            binding.txtTarget.text = "$scheme://${tx.host}"
            binding.editRequest.setText(tx.rawRequest())
        } else {
            binding.txtTarget.text = "Sin transacción base — escribe host manualmente en el request"
        }

        binding.btnSend.setOnClickListener { send() }
    }

    private fun send() {
        val raw = binding.editRequest.text.toString()
        binding.txtResponse.text = "Enviando…"
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching {
                val socket: Socket = if (scheme == "https") {
                    (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(host, port)
                } else {
                    Socket(host, port)
                }
                socket.use { s ->
                    s.getOutputStream().write(raw.toByteArray(Charsets.ISO_8859_1))
                    s.getOutputStream().flush()
                    val input = s.getInputStream()
                    val statusLine = HttpParser.readLine(input) ?: "(sin respuesta)"
                    val headers = HttpParser.readHeaders(input)
                    val body = HttpParser.readBody(input, headers)
                    buildString {
                        append(statusLine).append("\n")
                        headers.forEach { (k, v) -> append("$k: $v\n") }
                        append("\n")
                        append(String(body, Charsets.UTF_8))
                    }
                }
            }.getOrElse { "Error: ${it.message}" }

            withContext(Dispatchers.Main) { binding.txtResponse.text = result }
        }
    }
}
