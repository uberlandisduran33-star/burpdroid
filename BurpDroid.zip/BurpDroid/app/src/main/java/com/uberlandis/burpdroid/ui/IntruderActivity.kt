package com.uberlandis.burpdroid.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.uberlandis.burpdroid.databinding.ActivityIntruderBinding
import com.uberlandis.burpdroid.mitm.HttpParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.Socket
import javax.net.ssl.SSLSocketFactory

class IntruderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIntruderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIntruderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.editTemplate.setText(
            "GET /buscar?q=§payload§ HTTP/1.1\r\nHost: ejemplo.com\r\nConnection: close\r\n\r\n"
        )
        binding.editPayloads.setText("test\n' OR '1'='1\n<script>alert(1)</script>\nadmin")
        binding.btnRun.setOnClickListener { run() }
    }

    private fun run() {
        val hostPort = binding.editHost.text.toString().trim()
        val scheme = binding.editScheme.text.toString().trim().ifEmpty { "https" }
        val template = binding.editTemplate.text.toString()
        val payloads = binding.editPayloads.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }

        if (hostPort.isEmpty() || !template.contains("§payload§")) {
            binding.txtResults.text = "Falta host o marcador §payload§ en la plantilla."
            return
        }

        val host = hostPort.substringBefore(':')
        val port = hostPort.substringAfter(':', if (scheme == "https") "443" else "80").toIntOrNull()
            ?: if (scheme == "https") 443 else 80

        binding.txtResults.text = "Ejecutando ${payloads.size} peticiones…\n"

        lifecycleScope.launch(Dispatchers.IO) {
            val sb = StringBuilder()
            for (payload in payloads) {
                val raw = template.replace("§payload§", payload)
                val start = System.currentTimeMillis()
                val line = runCatching {
                    val socket: Socket = if (scheme == "https")
                        (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(host, port)
                    else Socket(host, port)
                    socket.use { s ->
                        s.getOutputStream().write(raw.toByteArray(Charsets.ISO_8859_1))
                        s.getOutputStream().flush()
                        val input = s.getInputStream()
                        val statusLine = HttpParser.readLine(input) ?: "(sin respuesta)"
                        val status = HttpParser.parseStatusLine(statusLine)
                        val headers = HttpParser.readHeaders(input)
                        val body = HttpParser.readBody(input, headers)
                        val ms = System.currentTimeMillis() - start
                        "payload=\"$payload\"  status=${status.status}  bytes=${body.size}  ${ms}ms"
                    }
                }.getOrElse { "payload=\"$payload\"  ERROR: ${it.message}" }

                sb.append(line).append("\n")
                withContext(Dispatchers.Main) { binding.txtResults.text = sb.toString() }
            }
        }
    }
}
