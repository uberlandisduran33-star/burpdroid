package com.uberlandis.burpdroid.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.uberlandis.burpdroid.data.TransactionRepository
import com.uberlandis.burpdroid.databinding.ActivityMainBinding
import com.uberlandis.burpdroid.mitm.CertificateAuthority
import com.uberlandis.burpdroid.service.ProxyService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: TransactionAdapter
    private val proxyPort = 8888

    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        adapter = TransactionAdapter { tx ->
            startActivity(TransactionDetailActivity.intent(this, tx.id))
        }
        binding.recyclerTransactions.layoutManager = LinearLayoutManager(this)
        binding.recyclerTransactions.adapter = adapter

        TransactionRepository.liveList.observe(this) { list ->
            adapter.submit(list)
            // Si hay algo en la cola de intercept y no está ya abierta la pantalla, ábrela.
            if (TransactionRepository.interceptQueue.isNotEmpty()) {
                startActivity(Intent(this, InterceptActivity::class.java))
            }
        }

        refreshStatus()

        binding.btnToggleProxy.setOnClickListener {
            if (ProxyService.isRunning) {
                stopService(Intent(this, ProxyService::class.java))
            } else {
                val i = Intent(this, ProxyService::class.java)
                i.putExtra(ProxyService.EXTRA_PORT, proxyPort)
                startForegroundService(i)
            }
            binding.root.postDelayed({ refreshStatus() }, 400)
        }

        binding.btnIntercept.setOnClickListener {
            TransactionRepository.interceptEnabled = !TransactionRepository.interceptEnabled
            refreshStatus()
        }

        binding.btnExportCa.setOnClickListener { exportCa() }
        binding.btnClear.setOnClickListener { TransactionRepository.clear() }
        binding.btnIntruder.setOnClickListener { startActivity(Intent(this, IntruderActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        binding.btnToggleProxy.text = if (ProxyService.isRunning) "Detener proxy" else "Iniciar proxy"
        binding.btnIntercept.text = "Intercept: ${if (TransactionRepository.interceptEnabled) "ON" else "OFF"}"
        binding.txtStatus.text = if (ProxyService.isRunning)
            "Proxy activo en 127.0.0.1:${ProxyService.listeningPort}. Configúralo como proxy manual del Wi-Fi e instala/confía en la CA exportada."
        else
            "Proxy detenido. Configura 127.0.0.1:$proxyPort como proxy manual del Wi-Fi."
    }

    private fun exportCa() {
        val ca = CertificateAuthority(applicationContext)
        val file = ca.certFileForExport
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/x-x509-ca-cert"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Compartir/instalar certificado CA"))
    }
}
