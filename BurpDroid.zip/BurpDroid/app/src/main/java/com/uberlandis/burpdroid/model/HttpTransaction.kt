package com.uberlandis.burpdroid.model

import java.util.UUID

enum class TxState { CAPTURED, INTERCEPTED, FORWARDED, DROPPED, EDITED }

data class HttpTransaction(
    val id: String = UUID.randomUUID().toString(),
    var method: String = "",
    var scheme: String = "http",
    var host: String = "",
    var path: String = "",
    var requestHeaders: MutableList<Pair<String, String>> = mutableListOf(),
    var requestBody: ByteArray = ByteArray(0),
    var responseStatus: Int = 0,
    var responseHeaders: MutableList<Pair<String, String>> = mutableListOf(),
    var responseBody: ByteArray = ByteArray(0),
    var timestamp: Long = System.currentTimeMillis(),
    var durationMs: Long = 0,
    var state: TxState = TxState.CAPTURED
) {
    val url: String get() = "$scheme://$host$path"

    fun rawRequest(): String {
        val sb = StringBuilder()
        sb.append("$method $path HTTP/1.1\r\n")
        requestHeaders.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        sb.append("\r\n")
        if (requestBody.isNotEmpty()) sb.append(String(requestBody, Charsets.UTF_8))
        return sb.toString()
    }

    fun rawResponse(): String {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 $responseStatus\r\n")
        responseHeaders.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        sb.append("\r\n")
        if (responseBody.isNotEmpty()) sb.append(String(responseBody, Charsets.UTF_8))
        return sb.toString()
    }
}
