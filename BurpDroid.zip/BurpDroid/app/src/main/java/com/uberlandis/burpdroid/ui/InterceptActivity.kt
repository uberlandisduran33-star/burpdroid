package com.uberlandis.burpdroid.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.uberlandis.burpdroid.data.TransactionRepository
import com.uberlandis.burpdroid.databinding.ActivityInterceptBinding
import com.uberlandis.burpdroid.mitm.HttpParser
import com.uberlandis.burpdroid.mitm.InterceptResolver
import com.uberlandis.burpdroid.model.HttpTransaction
import com.uberlandis.burpdroid.model.TxState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

class InterceptActivity : AppCompatActivity() {

    private lateinit var binding: ActivityInterceptBinding
    private var current: HttpTransaction? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInterceptBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadNext()

        binding.btnForward.setOnClickListener {
            val tx = current ?: return@setOnClickListener
            val edited = parseEdited(tx, binding.editRequest.text.toString())
            edited.state = TxState.EDITED
            TransactionRepository.update(edited)
            InterceptResolver.resolve(tx.id, edited)
            loadNext()
        }

        binding.btnDrop.setOnClickListener {
            val tx = current ?: return@setOnClickListener
            tx.state = TxState.DROPPED
            TransactionRepository.update(tx)
            InterceptResolver.resolve(tx.id, null)
            loadNext()
        }
    }

    /** Espera (en background) a que llegue algo a la cola de intercept, sin bloquear la UI. */
    private fun loadNext() {
        current = null
        lifecycleScope.launch(Dispatchers.IO) {
            val tx = TransactionRepository.interceptQueue.poll() ?: run {
                withContext(Dispatchers.Main) { finish() }
                return@launch
            }
            withContext(Dispatchers.Main) {
                current = tx
                binding.txtTarget.text = "${tx.scheme}://${tx.host}"
                binding.editRequest.setText(tx.rawRequest())
            }
        }
    }

    private fun parseEdited(original: HttpTransaction, raw: String): HttpTransaction {
        val input = ByteArrayInputStream(raw.toByteArray(Charsets.ISO_8859_1))
        val reqLine = HttpParser.parseRequestLine(HttpParser.readLine(input) ?: "GET / HTTP/1.1")
        val headers = HttpParser.readHeaders(input)
        val body = HttpParser.readBody(input, headers)
        return original.copy(
            method = reqLine.method,
            path = reqLine.target,
            requestHeaders = headers,
            requestBody = body
        )
    }
}
