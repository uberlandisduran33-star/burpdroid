package com.uberlandis.burpdroid.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.uberlandis.burpdroid.mitm.CertificateAuthority
import com.uberlandis.burpdroid.mitm.MitmProxyServer

class ProxyService : Service() {

    companion object {
        const val EXTRA_PORT = "port"
        const val CHANNEL_ID = "burpdroid_proxy"
        const val NOTIF_ID = 1
        var isRunning = false
            private set
        var listeningPort = 0
            private set
    }

    private var server: MitmProxyServer? = null

    override fun onCreate() {
        super.onCreate()
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mgr.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Proxy BurpDroid", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val port = intent?.getIntExtra(EXTRA_PORT, 8888) ?: 8888
        listeningPort = port

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BurpDroid proxy activo")
            .setContentText("Escuchando en 127.0.0.1:$port")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, notification)

        if (server == null) {
            val ca = CertificateAuthority(applicationContext)
            server = MitmProxyServer(applicationContext, port, ca)
            server?.start()
            isRunning = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
