package com.uberlandis.burpdroid.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.uberlandis.burpdroid.databinding.ItemTransactionBinding
import com.uberlandis.burpdroid.model.HttpTransaction

class TransactionAdapter(
    private var items: List<HttpTransaction> = emptyList(),
    private val onClick: (HttpTransaction) -> Unit
) : RecyclerView.Adapter<TransactionAdapter.VH>() {

    inner class VH(val binding: ItemTransactionBinding) : RecyclerView.ViewHolder(binding.root)

    fun submit(newItems: List<HttpTransaction>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val tx = items[position]
        holder.binding.txtMethodStatus.text = "${tx.method}  ${tx.responseStatus.takeIf { it > 0 } ?: "…"}  [${tx.state}]"
        holder.binding.txtUrl.text = tx.url
        holder.itemView.setOnClickListener { onClick(tx) }
    }

    override fun getItemCount() = items.size
}
